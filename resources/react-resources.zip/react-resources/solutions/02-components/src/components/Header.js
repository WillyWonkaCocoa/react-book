function Header() {
    return (
        <header className='header-component'>
            <h1>Ottergram</h1>
        </header>
    )
}

export default Header;
