module.exports = {
  cookieName: 'coffeeJWT',
  port: 3030,
  secret: 'bnr-secret-sauce', // in a real app this would be in a .env file/environment variable or other safe place
};
