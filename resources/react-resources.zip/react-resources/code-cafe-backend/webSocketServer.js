const WebSocket = require('ws');

module.exports = new WebSocket.Server({ noServer: true });
