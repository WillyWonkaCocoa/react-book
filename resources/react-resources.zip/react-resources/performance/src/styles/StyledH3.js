import styled from 'styled-components';

const StyledH3 = styled.h3`
  margin-bottom: 0;
`;

export default StyledH3;
