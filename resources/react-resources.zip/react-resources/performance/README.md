# React Performance Penguins

Penguin Source: https://www.flickr.com/photos/141457238@N03/26834524313 Public Domain
